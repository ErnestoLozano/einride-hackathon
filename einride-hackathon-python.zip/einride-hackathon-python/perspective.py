import cv2
import numpy as np

def perspective_view(image):
    img_width = image.shape[1]
    img_height = image.shape[0]
    src_points = np.float32(
                            [[0, 0.8*img_height],
                            [0.2*img_width, 0.5*img_height],
                            [0.8*img_width, 0.5*img_height], 
                            [img_width, 0.8*img_height]])
    dst_points = np.float32(
                            [[(img_width/8-20), img_height], 
                            [(img_width/8), 0], 
                            [(img_width*7/8), 0], 
                            [(img_width*7/8+20), img_height]])
    M = cv2.getPerspectiveTransform(src_points, dst_points)
    # Minv = cv2.getPerspectiveTransform(dst_points, src_points)
    img_warped = cv2.warpPerspective(image, M, (img_width, img_height), cv2.INTER_LINEAR)
    return img_warped