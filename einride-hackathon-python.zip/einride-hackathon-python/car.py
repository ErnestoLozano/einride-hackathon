import websocket
import _thread
import time
import cv2

from pid_controller import *
from find_midlane import *


host = "cheetah"
port = 8887

socket_address = f"ws://{host}:{port}/wsDrive"
video_address = f"http://{host}:{port}/video"

def on_message(ws, message):
    print(message)


def on_error(ws, error):
    print(error)


def on_close(ws, close_status_code, close_msg):
    print("### closed ###")


def on_open(ws):
    def run(*args):
        # your car logic here

        cap = cv2.VideoCapture(video_address)
        
        ret, frame = cap.read()
        # height = frame.shape[0]
        # width = frame.shape[1]
   
        #PID SETTINGS
        angle = 0.0
        throttle = 0.2
        throttle_const = 0.25
        throttle_coeff = 0.1
        max_steering_angle = 1
        max_throttle = 0.4
        pid_sample_time = 0.01
        tau_p = 1
        tau_i = 0.1
        tau_d = 0.05
        
        while True:
            ret, frame = cap.read()
            # do something based on the frame
            center_position = find_midlane(frame)
            
            angle, throttle = move(center_position, max_steering_angle, max_throttle, throttle_const, throttle_coeff, tau_p, tau_d, tau_i, pid_sample_time)

            message = f"{{\"angle\":{angle},\"throttle\":{throttle},\"drive_mode\":\"user\",\"recording\":false}}"
            ws.send(message)
            print(message)

    _thread.start_new_thread(run, ())


if __name__ == "__main__":
    websocket.enableTrace(True)
    ws = websocket.WebSocketApp(socket_address,
                                on_open=on_open,
                                on_message=on_message,
                                on_error=on_error,
                                on_close=on_close)

    ws.run_forever()


