import cv2
import numpy as np
import matplotlib.pyplot as plt
from helper import *
from color_grad_bin import *
from fit_poly import *
from perspective import *

def find_midlane(image):
    lane_image = np.copy(image)
    img_warped = perspective_view(lane_image)

    thresh = (150, 255)
    l_channel = hls_threshold(img_warped, 'l', thresh)
    sxbinary = abs_sobel_thresh(img_warped, sobel_kernel=5, thresh=(120,255))
    meg_binary = mag_thresh(img_warped, sobel_kernel=5, mag_thresh=(120,255))
    combined_binary = np.zeros_like(sxbinary)
    combined_binary[ (sxbinary == 1) | (meg_binary == 1) & (l_channel == 1)] = 1

    left_fit_init, right_fit_init = init_findlane(combined_binary, nwindows=8, margin=50, minpix=50)
    _, pos_midlane, _ = search_around_poly(combined_binary, left_fit_init, right_fit_init)
    return pos_midlane

