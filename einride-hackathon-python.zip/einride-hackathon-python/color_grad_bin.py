import cv2
import numpy as np
from helper import *
## Define three different approaches of gradient threshold.
def abs_sobel_thresh(img, orient='x', sobel_kernel=3, thresh=(0, 255)):
    # Calculate directional gradient
    # Apply threshold
    gray = cv2.cvtColor(img, cv2.COLOR_RGB2GRAY)
    gray = gaussian_blur(gray, 5)
    if orient == 'x':
        sobel = cv2.Sobel(gray, cv2.CV_64F,1, 0, ksize=sobel_kernel)
    elif orient == 'y':
        sobel = cv2.Sobel(gray, cv2.CV_64F,0 ,1, ksize=sobel_kernel)
    abs_sobel = np.absolute(sobel)
    scaled_sobel = np.uint8(255*abs_sobel/np.max(abs_sobel))
    grad_binary = np.zeros_like(scaled_sobel)
    grad_binary[(scaled_sobel >= thresh[0]) & (scaled_sobel <= thresh[1])] = 1
    
    return grad_binary


def mag_thresh(img, sobel_kernel=3, mag_thresh=(0, 255)):
    # Calculate gradient magnitude
    # Apply threshold
    gray = cv2.cvtColor(img, cv2.COLOR_RGB2GRAY)
    gray = gaussian_blur(gray, 5)
    sobelx = cv2.Sobel(gray, cv2.CV_64F, 1, 0, ksize = sobel_kernel)
    sobely = cv2.Sobel(gray, cv2.CV_64F, 0, 1, ksize = sobel_kernel)
    mag_sobel = np.sqrt(sobelx ** 2 + sobely ** 2)
    scaled_sobel = np.uint8(255*mag_sobel/np.max(mag_sobel))
    mag_binary = np.zeros_like(scaled_sobel)
    mag_binary[(scaled_sobel >= mag_thresh[0]) & (scaled_sobel <= mag_thresh[1])] = 1
    
    return mag_binary


def dir_threshold(img, sobel_kernel=3, thresh=(0, np.pi/2)):
    # Calculate gradient direction
    # Apply threshold
    gray = cv2.cvtColor(img, cv2.COLOR_RGB2GRAY)
    gray = gaussian_blur(gray, 5)
    sobelx = cv2.Sobel(gray, cv2.CV_64F, 1, 0, ksize = sobel_kernel)
    sobely = cv2.Sobel(gray, cv2.CV_64F, 0, 1, ksize = sobel_kernel)
    abs_sobelx = np.absolute(sobelx)
    abs_sobely = np.absolute(sobely)
    grad_dir = np.arctan2(abs_sobely, abs_sobelx)
    dir_binary = np.zeros_like(grad_dir)
    dir_binary[(grad_dir >= thresh[0]) & (grad_dir <= thresh[1])] = 1
    
    return dir_binary


## Define color threshold for different channels
def hls_threshold(image, channel='s', thresh=(90, 255)):
    # Apply threshold to specified color channel
    # Output binary image
    img = np.copy(image)
    hls = cv2.cvtColor(img, cv2.COLOR_RGB2HLS)
    h_channel = hls[:, :, 0]
    l_channel = hls[:, :, 1]
    s_channel = hls[:, :, 2]
    if channel == 's':
        hls_binary = np.zeros_like(s_channel)
        hls_binary[(s_channel >= thresh[0]) & (s_channel <= thresh[1])] = 1
    elif channel == 'l':
        hls_binary = np.zeros_like(l_channel)
        hls_binary[(l_channel >= thresh[0]) & (l_channel <= thresh[1])] = 1
    elif channel == 'h':
        hls_binary = np.zeros_like(h_channel)
        hls_binary[(h_channel >= thresh[0]) & (h_channel <= thresh[1])] = 1
    
    return hls_binary


def rgb_threshold(image, channel='r', thresh=(200, 255)):
    # Apply threshold to specified color channel
    # Output binary image
    rgb = np.copy(image)
    r_channel = rgb[:, :, 0]
    g_channel = rgb[:, :, 1]
    b_channel = rgb[:, :, 2]
    if channel == 'r':
        rgb_binary = np.zeros_like(r_channel)
        rgb_binary[(r_channel >= thresh[0]) & (r_channel <= thresh[1])] = 1
    elif channel == 'g':
        rgb_binary = np.zeros_like(g_channel)
        rgb_binary[(g_channel >= thresh[0]) & (g_channel <= thresh[1])] = 1
    elif channel == 'b':
        rgb_binary = np.zeros_like(b_channel)
        rgb_binary[(b_channel >= thresh[0]) & (b_channel <= thresh[1])] = 1
    
    return rgb_binary



def labBSelect(img, thresh=(155, 255)):
    lab = cv2.cvtColor(img, cv2.COLOR_RGB2Lab)
    lab_b = lab[:,:,2]
    # don't normalize if there are no yellows in the image
    if np.max(lab_b) > 100:
        lab_b = lab_b*(255/np.max(lab_b))
    # 2) Apply a threshold to the L channel
    binary_output = np.zeros_like(lab_b)
    binary_output[((lab_b > thresh[0]) & (lab_b <= thresh[1]))] = 1
    # 3) Return a binary image of threshold result
    return binary_output